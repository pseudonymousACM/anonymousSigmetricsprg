figs_labels = {
	'target': 'Target / Class / Label',  # TODO: rename to label and label only.
	'node': 'Node', 'node_index': 'Node',
	'count': 'Count',
	'round': 'Round',
	'run': 'Run',
	'min_similarity': 'Min. Similarity',
	'accuracy': 'Accuracy', 'mean_loss': 'Mean (over batches) Loss', 'recall': 'Recall', 'precision': 'Precision',
	'ndcg': 'NDCG',
	'duration_seconds': 'Duration (seconds)'
}
