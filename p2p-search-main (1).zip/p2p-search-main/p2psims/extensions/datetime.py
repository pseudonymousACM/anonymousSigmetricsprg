from datetime import datetime
from datetime import timezone

EPOCH = datetime(1970, 1, 1, tzinfo=timezone.utc)
